// dropdown-submenu //

 		 $(document).ready(function(){
  $('.dropdown-submenu a.dropdown-item').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});  

 // owl-carousel

$(document).ready(function(){
    $('.owl-one').owlCarousel({
        loop:true,
        margin:0,
        nav:true,
		autoplay:true,
        responsive:{
            0:{
                items:1
            },
			 480:{
                items:2
            },
            600:{
                items:3
            },
			 768:{
                items:3
            },
            1000:{
                items:6
            }
        }
    });

    $('.owl-two').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
		autoplay:true,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:1
            },
            1000:{
                items:3
            }
        }
    });

    $('.owl-three').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:2
            },
            1000:{
                items:1
            }
        }
    });
});

// End  

 $(document).ready(function(){
  $('.slider8').bxSlider({
    mode: 'vertical',
    slideMaxWidth: 211,
    minSlides: 4,
    slideMargin: 7
  });
});
	